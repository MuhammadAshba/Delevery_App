const express= require('express')
const app= express()

const bodyParser= require('body-parser')
const { json } = require('body-parser')
const dotenv= require('dotenv').config()
const serviceProvider= require('./Routes/ServiceProviderRoutes')
const connectDB= require('./Config/db')
connectDB();

app.use(bodyParser.json())

app.get('/', (req, res) => {
  res.send('Server is Working')
})


app.use('/SP', serviceProvider) 



app.listen(process.env.PORT,  ()=>{

            console.log(`Server is running on ${process.env.PORT}`)
})