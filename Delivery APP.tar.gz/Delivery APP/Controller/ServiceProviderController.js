
const ServiceProvider = require('../Model/ServiceProviderModel')
const Offer= require('../Model/offerModel')






exports.createProvider=async(req,res)=>{

      const Provider= req.body;
          // console.log(Provider)
       try {
      
           await ServiceProvider.create(Provider);
    
       } catch (error) {
         res.send(`Error in Signup`)
       }

res.status(200).send(`Request is going to be success `)

}




exports.logIn=(req,res)=>{

  const Email= req.body.email;
  const Password= req.body.password;
  console.log(Email)
  console.log(Password)


res.status(200).send(`Login Request is going to be success `)
    
}





exports.generateOffer=async(req,res)=>{

  const offer= req.body;
  // console.log(order)
  try {
        await Offer.create(offer)
  } catch (error) {

    res.send(`Error in Generating Order`)
    
  }

res.status(200).send(`generate Request is going to be success `)
        
 }




exports.updateOffer=(req,res)=>{


res.status(200).send(`Update Request is going to be success `)
            
}





exports.getOffers=async(req,res)=>{

  try {
        const offers = await Offer.find()

         res.status(201).json({
          Data: offers
         })
  } catch (error) {
    res.send(`Error in Get Request`)
    
  }

res.status(200).send(`Get Offers Request is going to be success `)
                
}










exports.deleteOffer=(req,res)=>{

res.status(200).send(`Delete Request is going to be success `)
                    
}