const mongoose= require('mongoose');
const { Schema } = mongoose;

const serviceProviderSchema = new mongoose.Schema({
  
  serviceProviderTypeId: String, 
  serviceProviderNumber: String,
  title:String,
  subTitle:String,
  mobile: String,
  email:String,
  country:String,
  city:String,
  password: String,
  responsiblePersonName:String, 
  shopLogoImg: String,
  bankIBANNum:String,
  bankIBANImg:String,
  sejelImg:String,
  address:String,
  fileshopLogo:String,
  fileIBANCardImg:String,
  filesejelImg:String
  
});

const ServiceProvider = mongoose.model('serviceProvider', serviceProviderSchema);

module.exports= ServiceProvider;