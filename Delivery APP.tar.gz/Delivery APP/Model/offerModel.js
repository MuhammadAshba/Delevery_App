const mongoose= require('mongoose');
const { Schema } = mongoose;

const OfferSchema = new mongoose.Schema({
  
  
     serviceProviderNumber: String,
     shopLogoImg: String,
     offerId: String,
     name: String,
     url: String,
     description:String,
     offerNum: String,
     offerImgFile: String
  
  
});

const  Offer= mongoose.model('offer', OfferSchema);

module.exports= Offer;