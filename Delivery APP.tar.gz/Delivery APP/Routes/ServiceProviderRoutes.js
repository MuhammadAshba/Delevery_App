
const express= require('express')
const router = express.Router()

const {createProvider,logIn,generateOffer,updateOffer,getOffers,deleteOffer}=require('../Controller/ServiceProviderController')


router.route('/Signup').post(createProvider)
router.route('/logIn').post(logIn)

router.route('/generate/offer').post(generateOffer)
router.route('/update/offer').put(updateOffer)
router.route('/get/Offers').get(getOffers)
router.route('/delete/offer').delete(deleteOffer)

module.exports= router; 